from project.configuration.worker import write_to_json, append_distances_to_json

def process_distances(distances, distances_center=None, target_value=75):
    """
    Обрабатывает массивы расстояний основной и центральной областей.
    Если хотя бы один массив не проходит проверку - возвращает "out_of_range"
    """
    # Обрабатываем основную область
    dst = []
    for distance in distances:
        dst.append(round(float(distance) / 62.2, 3))

    # Обрабатываем центральную область, если есть
    dst_center = []
    if distances_center:
        for distance in distances_center:
            dst_center.append(round(float(distance) / 62.2, 3))

    # Сохраняем все расстояния
    all_distances = dst + dst_center
    append_distances_to_json("project/configuration/statistics.json", all_distances)

    # Если оба массива пустые, возвращаем "out_of_range"
    if not distances and not distances_center:
        write_to_json("project/configuration/distances.json", "distances_state", 0)
        return "out_of_range"

    # Проверяем основную область
    main_within_tolerance = True
    if distances:
        main_within_tolerance = all(
            target_value - 2 <= d <= target_value + 7.46
            for d in distances
        )

    # Проверяем центральную область
    center_within_tolerance = True
    if distances_center:
        center_within_tolerance = all(
            target_value - 2 <= d <= target_value + 7.46
            for d in distances_center
        )

    # Если обе области в допуске
    if main_within_tolerance and center_within_tolerance:
        write_to_json("project/configuration/distances.json", "distances_state", 1)
        return "within_tolerance"

    # Если мы попали сюда, значит есть отклонение больше чем ±tolerance
    write_to_json("project/configuration/distances.json", "distances_state", 3)
    return "out_of_range"