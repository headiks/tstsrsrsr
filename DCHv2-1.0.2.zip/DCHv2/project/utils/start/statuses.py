import os
import json


def verify_statuses_file():
    config_path = os.path.join('project', 'station', 'statuses.json')

    expected_structure = {
        "paused": 0,
        "stopped": 0,
        "skip_cell": 0,
        "moved_to_cell": 0,
        "moved_to_home": 0,
        "right_view_waiting": 0
    }

    try:
        if not os.path.exists(config_path) or os.path.getsize(config_path) == 0:
            return False

        with open(config_path, 'r', encoding="UTF-8") as file:
            current_data = json.load(file)

        return current_data == expected_structure

    except FileNotFoundError:
        print(f"Ошибка: файл {config_path} не найден")
        return False

    except json.JSONDecodeError:
        print(f"Ошибка: неверный формат JSON в файле {config_path}")
        return False

    except Exception as e:
        print(f"Неизвестная ошибка при проверке statuses.json: {e}")
        return False


def reset_statuses_file():
    config_path = os.path.join('project', 'station', 'statuses.json')

    correct_structure = {
        "paused": 0,
        "stopped": 0,
        "skip_cell": 0,
        "moved_to_cell": 0,
        "moved_to_home": 0,
        "right_view_waiting": 0
    }

    try:
        os.makedirs(os.path.dirname(config_path), exist_ok=True)

        if os.path.exists(config_path) and os.path.getsize(config_path) > 0:
            try:
                with open(config_path, 'r', encoding="UTF-8") as file:
                    existing_data = json.load(file)

                if set(existing_data.keys()) == set(correct_structure.keys()):
                    for key in correct_structure:
                        if key in existing_data and isinstance(existing_data[key], (int, float)):
                            correct_structure[key] = existing_data[key]
            except (json.JSONDecodeError, UnicodeDecodeError):
                print(f"Файл {config_path} поврежден, используется структура по умолчанию")
                pass

        if os.path.exists(config_path):
            os.remove(config_path)

        with open(config_path, 'w', encoding="UTF-8") as file:
            json.dump(correct_structure, file, indent=4)
            file.write("\n")

        return True

    except Exception as e:
        print(f"Ошибка при сбросе файла statuses.json: {e}")

        try:
            if os.path.exists(config_path):
                os.remove(config_path)
            with open(config_path, 'w', encoding="UTF-8") as file:
                json.dump(correct_structure, file, indent=4)
                file.write("\n")
            return True
        except Exception as final_error:
            print(f"Критическая ошибка при создании statuses.json: {final_error}")
            return False
