import os
import json
from curses.ascii import isdigit


def verify_station_coordinates():
    config_path = os.path.join('project', 'configuration', 'coordinates.json')

    try:
        if not os.path.exists(config_path) or os.path.getsize(config_path) == 0:
            return False

        with open(config_path, 'r', encoding="UTF-8") as file:
            config = json.load(file)

        expected_structure = {
            "x_coordinate_of_the_first_cell": 0,
            "y_coordinate_of_the_first_cell": 0,
            "z_coordinate_of_the_first_cell": 0,
            "current_coordinate_of_the_station_by_x": 0,
            "current_coordinate_of_the_station_by_y": 0,
            "current_coordinate_of_the_station_by_z": 0,
            "movement_step": 0.1
        }

        if set(expected_structure.keys()) != set(config.keys()):
            return False

        for key in expected_structure.keys():
            if not isinstance(config[key], type(expected_structure[key])):
                return False

        x_zero = config.get("current_coordinate_of_the_station_by_x", None) == 0
        y_zero = config.get("current_coordinate_of_the_station_by_y", None) == 0
        z_zero = config.get("current_coordinate_of_the_station_by_z", None) == 0

        if x_zero and y_zero and z_zero:
            return True
        else:
            return False

    except FileNotFoundError:
        print(f"Ошибка: файл {config_path} не найден")
        return False

    except json.JSONDecodeError:
        print(f"Ошибка: неверный формат JSON в файле {config_path}")
        return False

    except Exception as e:
        print(f"Неизвестная ошибка при проверке координат: {e}")
        return False


def reset_station_coordinates():
    config_path = os.path.join('project', 'configuration', 'coordinates.json')

    correct_structure = {
        "x_coordinate_of_the_first_cell": 0,
        "y_coordinate_of_the_first_cell": 0,
        "z_coordinate_of_the_first_cell": 0,
        "current_coordinate_of_the_station_by_x": 0,
        "current_coordinate_of_the_station_by_y": 0,
        "current_coordinate_of_the_station_by_z": 0,
        "movement_step": 0.1
    }

    try:
        os.makedirs(os.path.dirname(config_path), exist_ok=True)

        if os.path.exists(config_path) and os.path.getsize(config_path) > 0:
            try:
                with open(config_path, 'r', encoding="UTF-8") as file:
                    config = json.load(file)

                for key in ["x_coordinate_of_the_first_cell",
                            "y_coordinate_of_the_first_cell",
                            "z_coordinate_of_the_first_cell",
                            "movement_step"]:
                    if key in config and isinstance(config[key], (int, float)):
                        correct_structure[key] = config[key]
            except (json.JSONDecodeError, UnicodeDecodeError):
                print(f"Файл {config_path} поврежден, используется структура по умолчанию")
                pass

        if os.path.exists(config_path):
            os.remove(config_path)

        with open(config_path, 'w', encoding="UTF-8") as file:
            json.dump(correct_structure, file, indent=4)

        return True

    except Exception as e:
        print(f"Ошибка при сбросе координат: {e}")

        try:
            if os.path.exists(config_path):
                os.remove(config_path)
            with open(config_path, 'w', encoding="UTF-8") as file:
                json.dump(correct_structure, file, indent=4)
            return True
        except Exception as final_error:
            print(f"Критическая ошибка при создании файла: {final_error}")
            return False
