import os
import json


def verify_distances_file():
    config_path = os.path.join('project', 'configuration', 'distances', 'json')

    expected_structure = {
        "distances_state": 1
    }

    try:
        # Проверяем, что файл существует и не пустой
        if not os.path.exists(config_path) or os.path.getsize(config_path) == 0:
            print(f"Файл {config_path} не существует или пуст")
            return False

        with open(config_path, 'r', encoding="UTF-8") as file:
            current_data = json.load(file)

        # Строгая проверка структуры и типа данных
        if not isinstance(current_data, dict):
            print(f"Файл {config_path} должен содержать объект, "
                  f"а не {type(current_data)}")
            return False

        if "distances_state" not in current_data:
            print(f"Файл {config_path} должен содержать ключ 'distances_state'")
            return False

        if not isinstance(current_data["distances_state"], int):  # Строго int
            print(
                f"Поле 'distances_state' должно быть целым числом (int), "
                f"а не {type(current_data['distances_state'])}")
            return False

        return current_data == expected_structure

    except FileNotFoundError:
        print(f"Ошибка: файл {config_path} не найден")
        return False

    except json.JSONDecodeError:
        print(f"Ошибка: неверный формат JSON в файле {config_path}")
        return False

    except Exception as e:
        print(f"Неизвестная ошибка при проверке distances.json: {e}")
        return False


def reset_distances_file():
    config_path = os.path.join('project', 'configuration', 'distances', 'json')

    correct_structure = {
        "distances_state": 1
    }

    try:
        os.makedirs(os.path.dirname(config_path), exist_ok=True)

        if os.path.exists(config_path):
            if not verify_distances_file():
                try:
                    os.remove(config_path)
                except Exception as remove_error:
                    print(f"Ошибка при удалении файла: {remove_error}")
            else:
                return True

        with open(config_path, 'w', encoding="UTF-8") as file:
            json.dump(correct_structure, file, indent=4)

        return True

    except Exception as e:
        print(f"Ошибка при сбросе distances.json: {e}")

        try:
            if os.path.exists(config_path):
                try:
                    os.remove(config_path)
                except:
                    pass

            with open(config_path, 'w', encoding="UTF-8") as file:
                json.dump(correct_structure, file)

            return True
        except Exception as final_error:
            print(f"Критическая ошибка при создании distances.json: {final_error}")
            return False
