import os
import json


def verify_position_file():
    config_path = os.path.join('project', 'configuration', 'position', 'json')

    expected_structure = {
        "condition": 0
    }

    try:
        if not os.path.exists(config_path) or os.path.getsize(config_path) == 0:
            print(f"Файл {config_path} не существует или пуст")
            return False

        with open(config_path, 'r', encoding="UTF-8") as file:
            current_data = json.load(file)

        if not isinstance(current_data, dict):
            print(f"Файл {config_path} должен содержать объект, "
                  f"а не {type(current_data)}")
            return False

        if "condition" not in current_data:
            print(f"Файл {config_path} должен содержать ключ 'condition'")
            return False

        if not isinstance(current_data["condition"], int):
            print(f"Поле 'condition' должно быть целым числом (int), "
                  f"а не {type(current_data['condition'])}")
            return False

        return current_data == expected_structure

    except FileNotFoundError:
        print(f"Ошибка: файл {config_path} не найден")
        return False

    except json.JSONDecodeError:
        print(f"Ошибка: неверный формат JSON в файле {config_path}")
        return False

    except Exception as e:
        print(f"Неизвестная ошибка при проверке position.json: {e}")
        return False


def reset_position_file():
    config_path = os.path.join('project', 'configuration', 'position', 'json')

    correct_structure = {
        "condition": 0
    }

    try:
        os.makedirs(os.path.dirname(config_path), exist_ok=True)

        if os.path.exists(config_path):
            if not verify_position_file():
                try:
                    os.remove(config_path)
                except Exception as remove_error:
                    print(f"Ошибка при удалении файла: {remove_error}")
            else:
                return True

        with open(config_path, 'w', encoding="UTF-8") as file:
            json.dump(correct_structure, file, indent=4)

        return True

    except Exception as e:
        print(f"Ошибка при сбросе position.json: {e}")

        try:
            if os.path.exists(config_path):
                try:
                    os.remove(config_path)
                except:
                    pass

            with open(config_path, 'w', encoding="UTF-8") as file:
                json.dump(correct_structure, file)

            return True
        except Exception as final_error:
            print(f"Критическая ошибка при создании position.json: {final_error}")
            return False
