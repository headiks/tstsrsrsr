import json
import os


def verify_statistics_file():
    config_path = os.path.join('project', 'configuration', 'statistics.json')

    try:
        if not os.path.exists(config_path) or os.path.getsize(config_path) == 0:
            return False

        with open(config_path, 'r', encoding="UTF-8") as file:
            content = file.read().strip()

        if content == '[]':
            return True
        else:
            return False

    except FileNotFoundError:
        print(f"Ошибка: файл {config_path} не найден")
        return False

    except json.JSONDecodeError:
        print(f"Ошибка: неверный формат JSON в файле {config_path}")
        return False

    except Exception as e:
        print(f"Неизвестная ошибка при проверке statistics.json: {e}")
        return False


def reset_statistics_file():
    config_path = os.path.join('project', 'configuration', 'statistics.json')

    try:
        os.makedirs(os.path.dirname(config_path), exist_ok=True)

        if os.path.exists(config_path):
            os.remove(config_path)

        with open(config_path, 'w', encoding="UTF-8") as file:
            file.write('[]')
            file.write('\n')

        return True

    except Exception as e:
        print(f"Ошибка при сбросе statistics.json: {e}")

        try:
            if os.path.exists(config_path):
                os.remove(config_path)
            with open(config_path, 'w', encoding="UTF-8") as file:
                file.write('[]')
                file.write('\n')
            return True
        except Exception as final_error:
            print(f"Критическая ошибка при создании statistics.json: {final_error}")
            return False
