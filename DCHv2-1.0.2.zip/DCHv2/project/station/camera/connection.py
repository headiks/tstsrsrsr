import cv2

from project.station.camera.validation import get_available_camera_indices_no_limit


def connect_to_cameras():
    """
        Подключается ко всем доступным камерам, используя OpenCV (cv2).
        Определяет индексы доступных камер с помощью get_available_camera_indices().

        Returns:
            list[cv2.VideoCapture]: Список объектов VideoCapture для каждой подключенной камеры.
                                     Возвращает пустой список, если ни одна камера не была открыта.
        """
    available_camera_indices = get_available_camera_indices_no_limit()

    camera_captures = []
    for index in available_camera_indices:
        cap = cv2.VideoCapture(index)
        if cap.isOpened():
            camera_captures.append(cap)
            print(f"Успешно подключились к камере с индексом {index}")
            return camera_captures

        print(f"Не удалось подключиться к камере с индексом {index}")
        return None

    return None
