def change_snake_button_color(snake_button, color):
    """
    Изменяет цвет указанного квадрата.

    Параметры:
    squares: Двумерный массив квадратов.
    X (int): Индекс строки.
    Y (int): Индекс столбца.
    Color: Новый цвет квадрата.

    Возвращает:
    NONE
    """
    snake_button.bgcolor = color
    snake_button.update()
