import flet as ft

from project.application.build import building_the_application
from project.utils.start.position import verify_position_file, reset_position_file
from project.utils.start.statuses import verify_statuses_file, reset_statuses_file
from project.utils.start.distances import verify_distances_file, reset_distances_file
from project.utils.start.statistics import verify_statistics_file, reset_statistics_file
from project.utils.start.coordinates import verify_station_coordinates, reset_station_coordinates

if not verify_station_coordinates():
    reset_station_coordinates()

if not verify_statistics_file():
    reset_statistics_file()

if not verify_statuses_file():
    reset_statuses_file()

if not verify_distances_file():
    reset_distances_file()

###if not verify_position_file():
###    reset_position_file()

ft.app(target=building_the_application)
