import psutil, os, time, serial.tools.list_ports

def hard_reset_com_port(port_name):
    if not port_name:
        return
    port_name = port_name.upper()
    for proc in psutil.process_iter(['pid']):
        try:
            for h in proc.open_files():
                if port_name in h.path.upper():
                    proc.kill()
                    time.sleep(.5)
        except:
            pass
    os.system(f'mode {port_name}: BAUD=115200 PARITY=n DATA=8 STOP=1 >nul 2>&1')

hard_reset_com_port('COM3')
print('Сброс COM3 выполнен.')