import cv2

cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("Ошибка: не удалось подключиться к камере")
    exit()

cap.set(cv2.CAP_PROP_FRAME_WIDTH, 10000)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 10000)

actual_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
actual_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

print(f"Разрешение: {actual_width}x{actual_height}")

while True:
    ret, frame = cap.read()

    if not ret:
        print("Ошибка: не удалось получить кадр")
        break

    cv2.imshow('Camera', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()