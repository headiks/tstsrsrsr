import os


def verify_statistics_file():
    config_path = os.path.join('project', 'configuration', 'statistics.json')

    try:
        with open(config_path, 'r') as file:
            content = file.read().strip()

        if content == '[]':
            # print("✓ Файл statistics.json корректен (пустой массив [])")
            return True
        else:
            # print("✗ Ошибка: statistics.json должен содержать пустой массив []")
            return False

    except FileNotFoundError:
        print(f"✗ Ошибка: файл {config_path} не найден")
        return False
    except Exception as e:
        print(f"✗ Неизвестная ошибка при проверке statistics.json: {e}")
        return False


def reset_statistics_file():
    config_path = os.path.join('project', 'configuration', 'statistics.json')

    try:
        os.makedirs(os.path.dirname(config_path), exist_ok=True)

        with open(config_path, 'w') as file:
            file.write('[]')

        # print("✓ Файл statistics.json установлен в пустой массив []")
        return True

    except Exception as e:
        print(f"✗ Ошибка при сбросе statistics.json: {e}")
        return False


def create_statistics_file_if_not_exists():
    config_path = os.path.join('project', 'configuration', 'statistics.json')

    if not os.path.exists(config_path):
        return reset_statistics_file()
    return True
