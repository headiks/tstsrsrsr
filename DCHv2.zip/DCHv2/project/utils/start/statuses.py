import os
import json


def verify_statuses_file():
    config_path = os.path.join('project', 'station', 'statuses.json')

    expected_structure = {
        "paused": 0,
        "stopped": 0,
        "skip_cell": 0,
        "moved_to_cell": 0,
        "moved_to_home": 0,
        "right_view_waiting": 0
    }

    try:
        with open(config_path, 'r') as file:
            current_data = json.load(file)
        return current_data == expected_structure
    except (FileNotFoundError, json.JSONDecodeError):
        return False
    except Exception:
        return False


def reset_statuses_file():
    config_path = os.path.join('project', 'station', 'statuses.json')

    correct_structure = {
        "paused": 0,
        "stopped": 0,
        "skip_cell": 0,
        "moved_to_cell": 0,
        "moved_to_home": 0,
        "right_view_waiting": 0
    }

    try:
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        with open(config_path, 'w') as file:
            json.dump(correct_structure, file, indent=4)
        return True
    except Exception:
        return False
