import os
import json


def verify_station_coordinates():
    config_path = os.path.join('project', 'configuration', 'coordinates.json')

    try:
        with open(config_path, 'r') as file:
            config = json.load(file)

        x_zero = config.get("current_coordinate_of_the_station_by_x", None) == 0
        y_zero = config.get("current_coordinate_of_the_station_by_y", None) == 0
        z_zero = config.get("current_coordinate_of_the_station_by_z", None) == 0

        if x_zero and y_zero and z_zero:
            # print("✓ Координаты станции корректны (все равны 0)")
            return True
        else:
            # print("✗ Ошибка: координаты станции должны быть равны 0 перед запуском")
            return False

    except FileNotFoundError:
        print(f"✗ Ошибка: файл {config_path} не найден")
        return False
    except json.JSONDecodeError:
        print(f"✗ Ошибка: неверный формат JSON в файле {config_path}")
        return False
    except Exception as e:
        print(f"✗ Неизвестная ошибка при проверке координат: {e}")
        return False


def reset_station_coordinates():
    config_path = os.path.join('project', 'configuration', 'coordinates.json')

    try:
        with open(config_path, 'r') as file:
            config = json.load(file)

        config["current_coordinate_of_the_station_by_x"] = 0
        config["current_coordinate_of_the_station_by_y"] = 0
        config["current_coordinate_of_the_station_by_z"] = 0

        with open(config_path, 'w') as file:
            json.dump(config, file, indent=4)

        # print("✓ Координаты станции установлены в 0")
        return True

    except Exception as e:
        print(f"✗ Ошибка при сбросе координат: {e}")
        return False