import time
import base64
from json import JSONDecodeError
import threading
import cv2
from datetime import datetime
from project.alghorithms.contour import draw_contour
from project.station.camera.connection import connect_to_cameras
from project.configuration.worker import read_from_json, write_to_json
from project.alghorithms.tolerance_calculation import process_distances
from project.station.camera.frame_settings import apply_settings_to_frame
from project.alghorithms.core import robot_lock, camera_lock
from project.station.requests import move_to_coordinates


def log_message(message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    print(f"[{timestamp}] {message}")


def update_camera_feed(left_image, right_image):
    cameras = connect_to_cameras()
    if not cameras:
        return

    def capture_frame(camera):
        with camera_lock:
            success, frame = camera.read()
            if success:
                frame = apply_settings_to_frame(frame)
                _, buffer = cv2.imencode(".jpg", frame)
                encoded_image = base64.b64encode(buffer.tobytes()).decode('utf-8')
                return encoded_image
        return None

    def reconnect_camera():
        nonlocal cameras
        log_message("🔄 Попытка переподключения камеры")
        if cameras:
            for camera in cameras:
                camera.release()
            cameras = []
        time.sleep(1)
        cameras = connect_to_cameras()
        return cameras is not None and len(cameras) > 0

    def calibrate_position():
        max_retries = 3
        for attempt in range(max_retries):
            frame = capture_frame(cameras[0])
            if frame:
                if (read_from_json("project/configuration/launch.json", "selected_tab") == 0 and
                        (read_from_json("project/station/statuses.json", "paused") == 0 and
                         read_from_json("project/station/statuses.json", "stopped") == 0)
                ):
                    _, _, offset_mm, rectangles_count, rectangle_widths, _ = draw_contour(frame)
                    current_x = read_from_json("project/configuration/coordinates.json",
                                               "current_coordinate_of_the_station_by_x")
                    current_y = read_from_json("project/configuration/coordinates.json",
                                               "current_coordinate_of_the_station_by_y")
                    current_z = read_from_json("project/configuration/coordinates.json",
                                               "current_coordinate_of_the_station_by_z")
                    new_x = current_x - (offset_mm / 10)

                    with robot_lock:
                        move_to_coordinates(new_x, current_y, current_z)

                    write_to_json("project/configuration/coordinates.json", "current_coordinate_of_the_station_by_x", new_x)
                return True
            elif attempt < max_retries - 1:
                log_message(f"⚠️ Повторная попытка захвата кадра для калибровки: {attempt + 1}")
                if not reconnect_camera():
                    break
                time.sleep(0.5)
        return False

    def process_with_retry():
        max_retries = 10
        best_frame = None
        best_data = None

        for attempt in range(max_retries):
            processing_frame = capture_frame(cameras[0])
            if not processing_frame:
                if attempt < max_retries - 1:
                    log_message(f"⚠️ Повторная попытка захвата кадра для обработки: {attempt + 1}")
                    if not reconnect_camera():
                        continue
                    time.sleep(0.5)
                continue

            right_image_base64, distances, offset_mm, rectangles_count, rectangle_widths, dark_percentages = draw_contour(
                processing_frame)

            right_image.src_base64 = right_image_base64
            right_image.update()

            valid_widths = all(18 <= width <= 28 for width in rectangle_widths) if rectangle_widths else False
            valid_dark = all(
                dark_percentage <= 10 for dark_percentage in dark_percentages) if dark_percentages else False

            frame_data = {
                "distances": distances,
                "offset_mm": offset_mm,
                "rectangles_count": rectangles_count,
                "rectangle_widths": rectangle_widths,
                "dark_percentages": dark_percentages
            }

            if rectangles_count == 8 and valid_widths and valid_dark:
                process_distances(distances)
                write_to_json("project/configuration/distances.json", "last_frame_data", frame_data)
                return True
            else:
                write_to_json("project/configuration/distances.json", "last_frame_data", frame_data)

                if rectangles_count == 8 and best_frame is None:
                    best_frame = right_image_base64
                    best_data = frame_data

                time.sleep(0.5)

        if best_frame is not None:
            write_to_json("project/configuration/distances.json", "last_frame_data", best_data)
            return True

        return False

    def update_loop(cameras_list):
        while True:
            try:
                if read_from_json("project/station/statuses.json", "moved_to_home") == 1:
                    if not cameras_list or not cameras_list[0].isOpened():
                        if not reconnect_camera():
                            left_image.src_base64 = ""
                            left_image.update()
                            write_to_json("project/station/statuses.json", "right_view_waiting", 0)
                            time.sleep(0.5)
                            continue

                    if calibrate_position():
                        frame = capture_frame(cameras_list[0])
                        if frame:
                            left_image.src_base64 = frame
                            left_image.update()

                            if read_from_json("project/station/statuses.json", "right_view_waiting") == 1:
                                process_with_retry()
                                write_to_json("project/station/statuses.json", "right_view_waiting", 0)
                    else:
                        left_image.src_base64 = ""
                        left_image.update()
                        write_to_json("project/station/statuses.json", "right_view_waiting", 0)

                    time.sleep(0.5)

                elif read_from_json("project/station/statuses.json", "moved_to_cell") == 1:
                    if not cameras_list or not cameras_list[0].isOpened():
                        if not reconnect_camera():
                            left_image.src_base64 = ""
                            left_image.update()
                            write_to_json("project/station/statuses.json", "right_view_waiting", 0)
                            time.sleep(0.5)
                            continue

                    if calibrate_position():
                        frame = capture_frame(cameras_list[0])
                        if frame:
                            left_image.src_base64 = frame
                            left_image.update()

                            if read_from_json("project/station/statuses.json", "right_view_waiting") == 1:
                                process_with_retry()
                                write_to_json("project/station/statuses.json", "right_view_waiting", 0)
                    else:
                        left_image.src_base64 = ""
                        left_image.update()
                        write_to_json("project/station/statuses.json", "right_view_waiting", 0)

                    time.sleep(0.5)

                else:
                    time.sleep(0.1)

            except JSONDecodeError:
                write_to_json("project/station/statuses.json", "right_view_waiting", 0)
                time.sleep(0.1)
                continue
            except Exception as e:
                log_message(f"❌ Ошибка в цикле обновления: {e}")
                write_to_json("project/station/statuses.json", "right_view_waiting", 0)
                time.sleep(0.1)

    write_to_json("project/station/statuses.json", "moved_to_home", 0)
    write_to_json("project/station/statuses.json", "moved_to_cell", 0)
    write_to_json("project/station/statuses.json", "right_view_waiting", 0)

    thread = threading.Thread(target=update_loop, args=[cameras], daemon=True)
    thread.start()