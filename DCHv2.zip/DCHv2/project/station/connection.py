"""
Файл описывает установление и контроль подключения к роботу через COM-порт.
"""
import serial
import serial.tools.list_ports

from project.application.addition.error_message import show_error


def detect_port():
    """
    Находит первый порт с описанием, содержащим 'USB-SERIAL'.
    Возвращает строку с именем порта или None, если порт не найден.
    """
    try:
        ports = serial.tools.list_ports.comports()
        # Поиск порта, который содержит 'USB-SERIAL' в описании (регистронезависимо)
        for port in ports:
            if "USB-SERIAL" in port.description.upper():
                return port.device
        # Если ничего не найдено
        print("Порт с 'USB-SERIAL' не найден.")
        return None
    except Exception as e:
        print(f"Ошибка при поиске порта: {e}")
        return None


def define_presets():
    """
    Определяет настройки подключения: порт, скорость передачи данных, таймаут.
    Возвращает список с настройками.
    """
    # port = detect_port()
    port = "COM3"
    if port is None:
        raise ValueError("Не удалось найти подходящий COM-порт.")

    baudrate = 115200
    timeout = 1

    return [port, baudrate, timeout]


def establish_connection(app_page):
    """
    Устанавливает подключение через Serial.
    Возвращает объект подключения или None, если подключение не удалось.
    """
    try:
        port, baudrate, timeout = define_presets()
        connection = serial.Serial(port, baudrate, timeout=timeout)

        # Очищаем входной и выходной буферы
        connection.reset_input_buffer()
        connection.reset_output_buffer()

        if connection.is_open:
            print(f"Подключение установлено: {port} @ {baudrate} bps")
            return connection

        print("Не удалось открыть соединение.")
        return None

    except serial.SerialException as e:
        print(f"Ошибка при подключении: {e}")
        return None

    except ValueError as e:
        print(f"Ошибка конфигурации: {e}")
        show_error("Ошибка конфигурации!", e, app_page)
        return None


def close_connection(connection):
    """
    Закрывает подключение, если оно открыто.
    """
    try:
        if connection and connection.is_open:
            connection.close()
            print("Соединение успешно закрыто.")
        else:
            print("Соединение уже закрыто или не было установлено.")

    except Exception as e:
        print(f"Ошибка при закрытии соединения: {e}")
