import os
import json
import threading

lock = threading.Lock()


def append_distances_to_json(file_path, distances):
    """
    Записывает данные в JSON файл. Если файл не существует, создает его.
    Параметры:
        filename (str): Имя файла, в который будут записаны данные
        distances (list): Список размеров расстояний между выводами.
    """
    try:
        # Читаем существующие данные
        with open(file_path, "r", encoding="utf-8") as file:
            data = json.load(file)  # Загружаем существующий JSON
    except (FileNotFoundError, json.JSONDecodeError):
        data = []  # Если файла нет или он пуст, создаем новый список

    # Добавляем новый список в данные
    data.append(distances)

    # Записываем обратно в файл
    with open(file_path, "w", encoding="utf-8") as file:
        json.dump(data, file, ensure_ascii=False, indent=4)


def write_to_json(path, key, value):
    """
    Записывает данные в JSON файл. Если файл не существует, создает его.
    Параметры:
        filename (str): Имя файла, в который будут записаны данные.
        key (str): Ключ, по которому будет сохранено значение.
        value (any): Значение, которое будет записано по указанному ключу.
    """
    with lock:
        if os.path.exists(path):
            with open(path, 'r', encoding="UTF-8") as file:
                data = json.load(file)
        else:
            data = {}

        data[key] = value

        with open(path, 'w', encoding="UTF-8") as file:
            json.dump(data, file, indent=4)


def write_to_json_nested(path, keys, value):
    """
    Записывает данные в JSON файл с поддержкой вложенных ключей.
    Параметры:
        path (str): Путь к файлу
        keys (list): Список ключей для вложенного доступа ['configs', 0, 'contour']
        value (any): Значение для записи
    """
    with lock:
        if os.path.exists(path):
            with open(path, 'r', encoding="UTF-8") as file:
                data = json.load(file)
        else:
            data = {}

        current = data
        for i, key in enumerate(keys[:-1]):
            next_key = keys[i + 1] if i + 1 < len(keys) else None

            if isinstance(key, int):
                while len(current) <= key:
                    current.append({} if isinstance(next_key, (str, int)) else None)
                if current[key] is None:
                    current[key] = {} if isinstance(next_key, (str, int)) else []
            else:
                if key not in current:
                    current[key] = {} if isinstance(next_key, (str, int)) else []
                elif current[key] is None:
                    current[key] = {} if isinstance(next_key, (str, int)) else []

            current = current[key]

        last_key = keys[-1]
        if isinstance(last_key, int):
            while len(current) <= last_key:
                current.append(None)
            current[last_key] = value
        else:
            current[last_key] = value

        with open(path, 'w', encoding="UTF-8") as file:
            json.dump(data, file, indent=4)


def read_from_json(path, key):
    """
    Читает данные из JSON файла по указанному ключу.
    Параметры:
        filename (str): Имя файла, из которого будут прочитаны данные.
        key (str): Ключ, по которому будет извлечено значение.
    Возвращает:
        any: Значение по указанному ключу, если ключ существует. Иначе None.
    """
    with lock:
        if os.path.exists(path):
            with open(path, 'r', encoding="UTF-8") as file:
                data = json.load(file)

            return data.get(key, None)

        return None


def read_from_json_nested(path, keys):
    """
    Читает вложенные данные из JSON файла.
    Параметры:
        path (str): Путь к файлу
        keys (list): Список ключей для вложенного доступа ['configs', 0, 'contour']
    Возвращает:
        any: Значение по указанному пути ключей, если существует. Иначе None.
    """
    with lock:
        if os.path.exists(path):
            with open(path, 'r', encoding="UTF-8") as file:
                data = json.load(file)

            current = data
            for key in keys:
                if isinstance(current, dict) and key in current:
                    current = current[key]
                elif isinstance(current, list) and isinstance(key, int) and key < len(current):
                    current = current[key]
                else:
                    return None
            return current
        return None


def read_json_to_list(path):
    try:
        with open(path, 'r', encoding='utf-8') as file:
            data = json.load(file)

            if isinstance(data, list) and all(isinstance(sublist, list) for sublist in data):
                return data

            raise ValueError("Данные в JSON-файле не являются двумерным списком")

    except FileNotFoundError:
        print(f"Ошибка: Файл {path} не найден")
        return None
    except json.JSONDecodeError:
        print(f"Ошибка: Файл {path} содержит некорректный JSON")
        return None
    except ValueError as e:
        print(e)
        return None
